import json,pathlib,statistics,math,sys
r=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else 'final-results')
def quant(a):
 a=sorted(a);return dict(median=statistics.median(a),p95=a[math.ceil(.95*len(a))-1])
output={'build':{},'paired':[],'pairedIncomplete':[],'idle':[],'idleIncomplete':[]}
for m in ['ngtsc','fast','api']:
 p=r/f'build-{m}.json'
 if p.exists():output['build'][m]=json.loads(p.read_text())['metrics']
 for v in ['6','6-latest','7','8']:
  paths={s:list(r.glob(f'paired-vite{v}-{s}-{m}-*.json')) for s in ['control','candidate']}
  if min(map(len,paths.values()))<5 or not all((d:=json.loads(p.read_text())).get('passed') and len(d.get('records',[]))==25 for ps in paths.values() for p in ps):
   if any(paths.values()):
    output['pairedIncomplete'].append({'mode':m,'vite':v,'gate':'unavailable','counts':{s:len(ps) for s,ps in paths.items()},'failures':[{'side':s,'file':p.name,'completedEdits':len(d.get('records',[])),'message':(d.get('failure') or {}).get('message')} for s,ps in paths.items() for p in ps if not (d:=json.loads(p.read_text())).get('passed')]})
   continue
  row={'mode':m,'vite':v,'sides':{}}
  for s in paths:
   records=[json.loads(p.read_text()) for p in paths[s]]
   assert all(d['passed'] for d in records)
   row['sides'][s]={metric:quant(t[metric] for d in records for t in d['records']) for metric in ['templateMs','stylesheetMs']}
   row['sides'][s]['ssrMs']=quant(t['ssr']['ms'] for d in records for t in d['records'])
   row['sides'][s]['firstSsrMs']=statistics.median(d['initialSsr']['ms'] for d in records)
   row['sides'][s]['cpuMs']=statistics.median((d['cpu']['user']+d['cpu']['system'])/1000 for d in records)
   row['sides'][s]['peakRssMiB']=statistics.median(d['kernelPeakRssBytes']/2**20 for d in records)
  row['changes']={metric:{q:(row['sides']['candidate'][metric][q]/row['sides']['control'][metric][q]-1)*100 for q in ['median','p95']} for metric in ['templateMs','stylesheetMs']}
  row['gate']=all(change<=5 for values in row['changes'].values() for change in values.values())
  output['paired'].append(row)
 for idle in [0,250,1000]:
  for order in ['browser','server']:
   paths={flag:list(r.glob(f'idle-{m}-{idle}-{order}-{flag}-*.json')) for flag in ['default','off']}
   if min(map(len,paths.values()))<3 or not all((d:=json.loads(p.read_text())).get('passed') and len(d.get('records',[]))==5 for ps in paths.values() for p in ps):
    output['idleIncomplete'].append({'mode':m,'idleMs':idle,'order':order,'counts':{flag:len(ps) for flag,ps in paths.items()}})
    continue
   row={'mode':m,'idleMs':idle,'order':order,'sides':{}}
   for flag in paths:
    ds=[json.loads(p.read_text()) for p in paths[flag]]
    assert all(d['passed'] for d in ds)
    row['sides'][flag]={'ssrMs':quant(t['ssr']['ms'] for d in ds for t in d['records']), 'firstSsrMs':statistics.median(d['initialSsr']['ms'] for d in ds), 'cpuMs':statistics.median((d['cpu']['user']+d['cpu']['system'])/1000 for d in ds),'peakRssMiB':statistics.median(d['kernelPeakRssBytes']/2**20 for d in ds)}
   output['idle'].append(row)
print(json.dumps(output,indent=2))
