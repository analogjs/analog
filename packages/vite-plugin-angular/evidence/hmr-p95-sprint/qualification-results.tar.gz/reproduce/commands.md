Use the archived artifacts to replay the exact measured bytes. Use Node **24.15.0** and pnpm **10.33.0**, an Analog checkout at the published head, and a new empty output root. Workspace source checks use Nx; the installed-consumer scripts exercise the packed package.

```sh
export QUAL_ROOT=/tmp/analog-hmr-p95-reproduction
export QUAL_EVIDENCE="$QUAL_ROOT/evidence"
export NX_DAEMON=false NX_NO_CLOUD=true
mkdir -p "$QUAL_EVIDENCE"
tar -xzf packages/vite-plugin-angular/evidence/hmr-p95-sprint/qualification-results.tar.gz -C "$QUAL_EVIDENCE"
cp "$QUAL_EVIDENCE/artifacts/control-p95.tgz" "$QUAL_ROOT/control-p95.tgz"
cp "$QUAL_EVIDENCE/artifacts/candidate-p95.tgz" "$QUAL_ROOT/candidate-p95.tgz"
export QUAL_SCRIPTS="$PWD/packages/vite-plugin-angular/scripts"
pnpm install --frozen-lockfile
pnpm nx run-many -t test,typecheck,typecheck-tests,eslint:lint,build -p vite-plugin-angular --parallel=2
python3 - <<'PY'
import os,pathlib
root=pathlib.Path(os.environ['QUAL_ROOT']); evidence=pathlib.Path(os.environ['QUAL_EVIDENCE'])
for vite in [6,'6-latest',7,8]:
    for side in ['control','candidate']:
        name=f'vite{vite}-{side}'; consumer=root/name; consumer.mkdir()
        for file in ['package.json','pnpm-lock.yaml']:
            text=(evidence/'consumers'/name/file).read_text().replace('<fixtures>',str(root))
            (consumer/file).write_text(text)
PY
for consumer in "$QUAL_ROOT"/vite*-*
do
  (cd "$consumer" && pnpm install --ignore-workspace --frozen-lockfile)
done
```

To rebuild the exact sources instead, create separate worktrees at `fd8b2890295b396c762d7a7d8e9b6a90759a0ae5` for the control and `e64b7d012fb6778b31e03f9581393c11d19b870d` for the candidate, then `git apply` the archive's `source/control.patch` and `source/candidate.patch` respectively. Install frozen dependencies, run the package Nx gates above, and `pnpm pack` from `packages/vite-plugin-angular/dist`. The archive manifest records measured artifact hashes and source trees; a newly packed tar can have packaging metadata differences, so the archived tarballs are the byte-exact replay inputs.

Run correctness first. The archive includes the 13-tuple matrix and the further native/fallback/ownership drivers; their recorded absolute roots are declared placeholders to substitute locally. The full matrix requires a second Node **20.19.5** executable for Angular 17–20. Individual packed checks can be invoked directly:

```sh
node "$QUAL_SCRIPTS/compiler-vite-smoke.mjs" --angular=22.0.0 --vite=8.2.2
node "$QUAL_SCRIPTS/compiler-vite-smoke.mjs" --angular=19.0.1 --vite=6.0.0 --node-executable=/absolute/path/to/node-20.19.5
```

After all correctness/build/profiling jobs finish, run the fixed comparison serially. The driver labels sides explicitly, retains existing JSON and incomplete logs, continues untouched cells, and returns failure if any worker fails. Use a fresh directory for a new cohort; never replace failed observations with retries.

```sh
python3 "$QUAL_EVIDENCE/reproduce/fixed-cohort.py" \
  --root "$QUAL_ROOT" --scripts "$QUAL_SCRIPTS" \
  --output "$QUAL_ROOT/results" --node "$(command -v node)"
python3 "$QUAL_EVIDENCE/reproduce/summarize.py" "$QUAL_ROOT/results" > "$QUAL_ROOT/summary.json"
```

The new suite requires the cohort manifest and preserves all nine all-mode soak outcomes. Its default `ngtsc` filename suffix labels the invocation, not the mode coverage. Run it outside the comparative window:

```sh
NODE_ENV=development node "$QUAL_SCRIPTS/compiler-qualification-suite.mjs" \
  --root="$QUAL_ROOT" --manifest="$QUAL_EVIDENCE/revisions.json" \
  --phase=soak --hmr --output="$QUAL_ROOT/short-soaks"
```

Each soak has 100 components, 60 edit pairs, three restarts and 100 queued callers. A 240,000 ms update window allows a one-second timer tolerance; the hard 300,000 ms process timeout includes startup and shutdown. The nine workers run concurrently for correctness and memory observations, not comparative latency. Vite 6.0 uses the Environment Runner because of its historical legacy-loader restart limitation; Vite 6.4.3 and 8.2.2 also cover the legacy SSR loader. Resource SSR reads start at the watcher boundary without manual invalidation.
