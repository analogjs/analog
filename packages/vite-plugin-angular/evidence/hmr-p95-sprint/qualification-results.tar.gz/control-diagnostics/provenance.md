# Control repair provenance

This is scratch-only diagnostic provenance. It is not comparative timing
evidence. Every listed runtime result uses Angular 22.0.0, Vite 6.0.0, Node
24.15.0, pnpm 10.33.0, one ngtsc/fast fixture component and the normal runtime
assertions; no result replaces the retained historical failed worker.

## Immutable control and retained historical failure

- Source revision: `fd8b2890295b396c762d7a7d8e9b6a90759a0ae5`
- Source tree: `00288f0f39917887dc07deedb7813b577712ea3b`
- Tar: `<historical-fixtures>/control/analogjs-vite-plugin-angular-3.0.0-alpha.86.tgz`
- Tar SHA-256: `777f380cd44fb2e1b3dce41ee3a076634e398c9fc6fa62056f39c0265ccac694`
- 100-edit result: `original-100/original-100.json` (also copied to
  `original-100.json`), SHA-256
  `3fc21840be1590adf5b7c71668c6562d19b5be2f601d94f9dc425d9d207cb9d9`;
  passed 100/100.
- Log: `original-100/original-100.log`.
- Retained, unmodified historical failed worker:
  `<historical-fixtures>/qualified21-results/paired-vite6-control-ngtsc-1.json`
  and `.log`; it failed after edit 17 and is the only worker used to describe
  the original intermittent failure.

Additional immutable-control diagnostics were intentionally retained when the
intermittent failure did not reproduce: `repaired-100/original-100-{2,3,4}.json`
and matching logs. They each passed 100/100. Their parent directory name is a
consumer scratch path, not an indication that they used a repaired tar.

## Superseded renderer-only diagnostic

- Revision: `c7003deae4493acc45484a2f773d890ad5212464`
- Source tree: `f2fc7136ccfb1fddb2f99338bbf2367362162690`
- Tar: `artifact-c7003/analogjs-vite-plugin-angular-3.0.0-alpha.86.tgz`
- Tar SHA-256: `6d5fcd33b6c69cc61dbf4783a6512c7f6eb914c0b195d2697ac2235ab3ec3939`
- Results: `repaired-100/repaired-100.json` and
  `repaired-100/repaired-100-2.json`, with matching logs; both passed 100/100.

This revision is superseded because its fast compiler still sent generated
metadata HMR through the post-transform AST/MagicString path. It must not be
used as a comparative control artifact.

## Final repaired control artifact

- Revision: `2283861272f094b0773841bb10895502f88c8235`
- Parent/baseline: `fd8b2890295b396c762d7a7d8e9b6a90759a0ae5`
- Source tree: `52db2d9a9a3c5bed2afa0518cf58a1c9845ae6fc`
- Tar: `artifact-228386/analogjs-vite-plugin-angular-3.0.0-alpha.86.tgz`
- Tar SHA-256: `64740753ba2edc3fbd6ced0cc1b180cc2b34f729e80bbbe98da9cb393d19ca90`
- Focused results: `repaired-100/revised-fast-25.json` (SHA-256
  `44d9710b3280af4616a60a2987710f5ed70d367bace301faf3b43f355cce0d84`)
  and `repaired-100/revised-ngtsc-25.json` (SHA-256
  `e3b110f95fea41a63aed0e514e45719bf8fb173758b1711ce40fdbb041ae2f1f`).
  Both passed 25/25 with no captured errors. Matching `.log` files sit beside
  the results.

## Correctness backport and fairness review

The final patch contains only the Angular renderer-cache HMR repair:

- Enable a serve-only metadata wrapper only for `liveReload && !isTest &&
  angularFullVersion >= 200000`, matching the candidate's compiler-mode and
  version guard.
- Before Angular metadata replacement, obtain each live `RendererFactory2` and
  call `componentReplaced(componentId)` when an existing component TView is
  present. Reload if a renderer cannot provide that API.
- Mirror the candidate fast compiler's direct HMR-footer helper import and
  early post-transform return. Fast output therefore does not incur a
  control-only AST parse, MagicString rewrite, or high-resolution source map.

The candidate's separate external-style event/listener and native stylesheet
mechanism are deliberately absent. No Effect loading, lazy runtime allocation,
SSR warming, stylesheet externalization, or compiler scheduling changes were
backported.

The repair is causally plausible and the same renderer helper behavior is
present in the candidate. It is not deterministic proof that the historical
one-in-five failure is eliminated: all six new 100-edit diagnostic runs passed,
including immutable-control runs. The historical failed worker remains the
recorded failure and the final frozen comparison must use only the final
`228386` tar for its control side.
