"""Run the fixed cohort serially, recording whole-host load without stopping peer work."""
from pathlib import Path
import os,subprocess,json,time,threading,datetime,hashlib
r=Path('<fixtures>'); wd=Path('<workspace>'); scripts=wd/'packages/vite-plugin-angular/scripts'; node='<node-installations>/v24.15.0/installation/bin/node'
output=r/'results'; output.mkdir(exist_ok=False)
manifest=json.loads((r/'revisions.json').read_text()); manifest['workerHashes']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in scripts.glob('compiler-*.mjs')}; manifest['startedAt']=datetime.datetime.now(datetime.UTC).isoformat(); manifest['cpuCount']=os.cpu_count(); manifest['affinity']=sorted(os.sched_getaffinity(0)); manifest['hostLoadBoundary']='No owned tests/builds/profilers overlap. Existing unrelated host services are not stopped; /proc/stat busy fraction and load averages sampled every 10 seconds.'
(output/'cohort-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
stop=threading.Event()
def monitor():
 previous=None
 with (output/'host-load.jsonl').open('x') as log:
  while not stop.is_set():
   values=list(map(int,Path('/proc/stat').read_text().splitlines()[0].split()[1:9])); current=(sum(values),values[3]+values[4]); delta=None if previous is None else 100*(1-(current[1]-previous[1])/(current[0]-previous[0])); previous=current
   log.write(json.dumps({'at':datetime.datetime.now(datetime.UTC).isoformat(),'hostBusyPercent':delta,'loadAverage':os.getloadavg()})+'\n');log.flush();stop.wait(10)
thread=threading.Thread(target=monitor,daemon=True);thread.start()
try:
 with (r/'performance-progress.log').open('x') as log:
  p=subprocess.run(['python3',str(r/'reproduce-fixed-cohort.py'),'--root',str(r),'--scripts',str(scripts),'--output',str(output),'--node',node],stdout=log,stderr=subprocess.STDOUT)
finally:
 stop.set();thread.join()
manifest['finishedAt']=datetime.datetime.now(datetime.UTC).isoformat();manifest['exitCode']=p.returncode;(output/'cohort-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
raise SystemExit(p.returncode)
