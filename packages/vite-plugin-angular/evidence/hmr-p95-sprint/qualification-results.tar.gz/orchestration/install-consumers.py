from pathlib import Path
import os,subprocess,concurrent.futures,json,time,tarfile
r=Path('<fixtures>'); env={**os.environ,'PATH':'<node-installations>/v24.15.0/installation/bin:'+os.environ['PATH']}
def run(pair):
 v,s=pair; d=r/f'vite{v}-{s}'; start=time.time()
 with (r/f'{d.name}-verified-install.log').open('w') as log:p=subprocess.run(['pnpm','install','--ignore-workspace','--frozen-lockfile','--prefer-offline'],cwd=d,env=env,stdout=log,stderr=subprocess.STDOUT)
 if p.returncode: raise RuntimeError(d.name)
 count=0
 with tarfile.open(r/f'{s}-p95.tgz') as tf:
  for member in tf.getmembers():
   if member.isfile():
    relative=Path(member.name).relative_to('package'); expected=tf.extractfile(member).read(); actual=(d/'node_modules/@analogjs/vite-plugin-angular'/relative).read_bytes(); assert actual==expected, str(relative); count+=1
 result={'consumer':d.name,'exit':p.returncode,'seconds':time.time()-start,'packedFilesByteVerified':count}; print(json.dumps(result),flush=True); return result
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool: results=list(pool.map(run,[(v,s) for v in [6,'6-latest',7,8] for s in ['control','candidate']]))
(r/'consumer-verification.json').write_text(json.dumps(results,indent=2)+'\n')
