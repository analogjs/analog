import subprocess,concurrent.futures,json,os,pathlib,time
root=pathlib.Path('<fixtures>');node='<node-installations>/v24.15.0/installation/bin/node';env=os.environ.copy();env['PATH']=str(pathlib.Path(node).parent)+':'+env['PATH'];env['NODE_ENV']='development';env.pop('VITEST',None)
cases=[(v,m,e,s) for v in [6,'6-latest',7,8] for m in ['ngtsc','api'] for e,s in [('Emulated','auto')]]+[(8,m,e,s) for m in ['ngtsc','api'] for e,s in [('None','auto'),('ShadowDom','auto'),('Emulated','metadata')]]+[(8,'fast','Emulated','auto')]
def run(case):
 v,m,e,s=case;name=f'p95-native-vite{v}-{m}-{e}-{s}';out=root/(name+'.json');start=time.time()
 with (root/(name+'.log')).open('w') as log:p=subprocess.run([node,'native-style.mjs',f'--mode={m}',f'--encapsulation={e}',f'--strategy={s}',f'--output={out}',*(['--externalize'] if m!='fast' and s=='auto' else [])],cwd=root/f'vite{v}-candidate',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 r=dict(name=name,exitCode=p.returncode,elapsedSeconds=time.time()-start);print(json.dumps(r),flush=True);return r
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(run,cases))
(root/'p95-native-summary.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(any(r['exitCode'] for r in results))
