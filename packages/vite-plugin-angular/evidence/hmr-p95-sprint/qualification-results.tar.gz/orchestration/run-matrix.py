import subprocess,concurrent.futures,json,os,pathlib,time
root=pathlib.Path('<fixtures>')
wd='<workspace>'
node='<node-installations>/v24.15.0/installation/bin/node'
old='<node-installations>/v20.19.5/installation/bin/node'
env=os.environ.copy();env['PATH']=str(pathlib.Path(node).parent)+':'+env['PATH'];env['PLAYWRIGHT_SKIP_BROWSER_GC']='1'
cases=[(v,'6.0.0') for v in ['17.3.12','18.2.14','19.0.0','19.0.1','20.0.0','20.1.0']]+[('21.0.0','7.0.0')]+[('22.0.0',v) for v in ['6.0.0','6.4.3','7.0.0','7.3.6','8.0.0','8.2.2']]
def run(case):
 a,v=case;name=f'p95-matrix-{a}-{v}';start=time.time();log=root/f'{name}.log'
 with log.open('w') as out:
  p=subprocess.run([node,'packages/vite-plugin-angular/scripts/compiler-vite-smoke.mjs',f'--angular={a}',f'--vite={v}',f'--node-executable={old if int(a.split(".")[0])<21 else node}'],cwd=wd,env=env,stdout=out,stderr=subprocess.STDOUT)
 result=dict(angular=a,vite=v,exitCode=p.returncode,elapsedSeconds=time.time()-start,log=str(log));print(json.dumps(result),flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool: results=list(pool.map(run,cases))
(root/'p95-matrix-summary.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(any(r['exitCode'] for r in results))
