from pathlib import Path
import subprocess,os,json,time
r=Path('<fixtures>');wd=Path('<workspace>');env={**os.environ,'PATH':'<node-installations>/v24.15.0/installation/bin:'+os.environ['PATH'],'NODE_ENV':'development'}
for name in ['matrix','native','extra']:
 p=r/f'qualified21-{name}-summary.json'
 while not p.exists():time.sleep(5)
 assert all(x['exitCode']==0 for x in json.loads(p.read_text())),name
print('Correctness prerequisites passed; starting fixed performance cohort',flush=True)
with (r/'qualified21-performance-progress.log').open('a') as log:subprocess.run(['python3',str(r/'resume-qualified21-performance.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
print('Comparative measurements finished; starting nine 15-minute soaks',flush=True)
with (r/'qualified21-soak-progress.log').open('w') as log:subprocess.run(['node','packages/vite-plugin-angular/scripts/compiler-qualification-suite.mjs',f'--root={r}','--phase=soak','--hmr',f'--output={r/"qualified21-soaks"}'],cwd=wd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
print('All qualification phases completed',flush=True)
