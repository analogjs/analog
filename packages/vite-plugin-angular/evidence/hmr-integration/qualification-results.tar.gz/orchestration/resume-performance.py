import subprocess,pathlib,os,time,json,shutil
r=pathlib.Path('<fixtures>');out=r/'qualified21-results';out.mkdir(exist_ok=True);wd=pathlib.Path('<workspace>');scripts=wd/'packages/vite-plugin-angular/scripts';node='<node-installations>/v24.15.0/installation/bin/node';env=os.environ.copy();env['PATH']=str(pathlib.Path(node).parent)+':'+env['PATH'];env['NODE_ENV']='development';env.pop('VITEST',None)
def run(name,args,cwd=wd,extra={}):
 if (out/(name+'.json')).exists(): return
 started=time.time()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run([node,*args],cwd=cwd,env={**env,**extra},stdout=log,stderr=subprocess.STDOUT)
 print(json.dumps(dict(name=name,exitCode=p.returncode,seconds=time.time()-started)),flush=True)
 if p.returncode and not name.startswith('paired-'):raise SystemExit(p.returncode)
for mode in ['ngtsc','fast','api']:
 run('build-'+mode,[str(scripts/'compiler-benchmark.mjs'),f'--baseline={r/"vite8-control"}',f'--candidate={r/"vite8-candidate"}',f'--output={out/f"build-{mode}.json"}','--samples=15'],extra={'ANALOG_PERF_FAST':'1' if mode=='fast' else '0','ANALOG_PERF_API':'1' if mode=='api' else '0'})
for mode in ['ngtsc','fast','api']:
 for vite in [6,'6-latest',7,8]:
  for sample in range(5):
   for side in (['candidate','control'] if sample%2 else ['control','candidate']):
    name=f'paired-vite{vite}-{side}-{mode}-{sample}'
    run(name,['--expose-gc','runtime.mjs',f'--mode={mode}','--edits=25','--event-latency',f'--output={out/(name+".json")}',*(['--expect-style-state'] if side=='candidate' else [])],cwd=r/f'vite{vite}-{side}')
# Keep intervals/start orders separate; three fresh alternating processes per flag.
for mode in ['ngtsc','fast','api']:
 for idle in [0,250,1000]:
  for order in ['browser','server']:
   for sample in range(3):
    for warmup in (['default','off'] if sample%2 else ['off','default']):
     name=f'idle-{mode}-{idle}-{order}-{warmup}-{sample}'
     run(name,['--expose-gc','runtime.mjs',f'--mode={mode}','--components=100','--edits=5',f'--ssr-idle-ms={idle}',f'--warmup={warmup}',f'--output={out/(name+".json")}',*(['--ssr-first'] if order=='server' else [])],cwd=r/'vite8-candidate')
failures=[p.name for p in out.glob('paired-*.json') if not json.loads(p.read_text()).get('passed')]
(out/'complete.json').write_text(json.dumps({'completed':True,'failures':failures})+'\n')
