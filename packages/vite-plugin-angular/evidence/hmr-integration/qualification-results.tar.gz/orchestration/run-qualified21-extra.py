from pathlib import Path
import subprocess,os,json,re,shutil,time
r=Path('<fixtures>');wd=Path('<workspace>');node='<node-installations>/v24.15.0/installation/bin/node';env={**os.environ,'PATH':str(Path(node).parent)+':'+os.environ['PATH'],'NODE_ENV':'development'};env.pop('VITEST',None)
results=[]
def run(name,cwd,args,exe=node):
 start=time.time()
 with (r/(name+'.log')).open('w') as log:p=subprocess.run([exe,*args,f'--output={r/(name+".json")}'],cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 row=dict(name=name,exitCode=p.returncode,seconds=time.time()-start);results.append(row);print(json.dumps(row),flush=True)
 if p.returncode:raise RuntimeError(name)
for v in [6,'6-latest',7,8]:
 for m in ['ngtsc','api']:run(f'qualified21-fallback-vite{v}-{m}',r/f'vite{v}-candidate',['native-style.mjs',f'--mode={m}','--strategy=metadata','--externalize'])
for a,v,modes in [('19.0.1','6.0.0',['ngtsc']),('20.0.0','6.0.0',['ngtsc']),('20.1.0','6.0.0',['ngtsc']),('21.0.0','7.0.0',['ngtsc','api'])]:
 consumer=Path(re.search('Installed-package evidence retained at (.+)',(r/f'qualified21-matrix-{a}-{v}.log').read_text()).group(1));exe=node if a.startswith('21') else '<node-installations>/v20.19.5/installation/bin/node';shutil.copyfile(wd/'packages/vite-plugin-angular/scripts/compiler-native-style-qualification.mjs',consumer/'native-final.mjs')
 with (r/f'qualified21-native-old-{a}-install.log').open('w') as log:subprocess.run(['pnpm','add','--ignore-workspace','sass@1.97.3'],cwd=consumer,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 for m in modes:
  for s in ['auto','metadata']:run(f'qualified21-native-old-{a}-{m}-{s}',consumer,['native-final.mjs',f'--mode={m}',f'--strategy={s}',*(['--externalize'] if not a.startswith('19') else [])],exe)
for m in ['ngtsc','fast','api']:run(f'qualified21-ownership-{m}',r/'vite8-candidate',['--expose-gc','ownership.mjs',f'--mode={m}','--edits=2'])
(r/'qualified21-extra-summary.json').write_text(json.dumps(results,indent=2)+'\n')
