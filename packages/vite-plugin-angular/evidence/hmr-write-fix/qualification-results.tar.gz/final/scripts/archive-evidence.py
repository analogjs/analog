"""Archive scoped qualification artifacts; never include installed dependencies."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import tarfile

parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
roots = {
    'write': Path('/mnt/buildvol/tmp/snyder/analog-hmr-write-2521'),
    'barrier': Path('/mnt/buildvol/tmp/snyder/analog-hmr-barrier-2521'),
    'final': Path('/mnt/buildvol/tmp/snyder/analog-hmr-fetch-2521'),
}
files = {}
for label, root in roots.items():
    for directory, dirs, names in os.walk(root):
        dirs[:] = [name for name in dirs if name not in {'node_modules', '.git', '.vite-cache', 'pack', 'barrier-pack', 'fetch-pack', 'control-final-pack'} and not name.startswith('runtime-project-')]
        for name in names:
            path = Path(directory) / name
            if path.is_symlink() or path == args.output or path.name == 'archive-manifest.json':
                continue
            if path.suffix in {'.json', '.log', '.mjs', '.md', '.patch', '.yaml', '.tgz', '.txt', '.html', '.py'}:
                files[f'{label}/{path.relative_to(root)}'] = path
inventory = json.loads((roots['write'] / 'evidence-inventory.json').read_text())
def extra(value):
    if isinstance(value, dict):
        for item in value.values():
            extra(item)
    elif isinstance(value, list):
        for item in value:
            extra(item)
    elif isinstance(value, str) and value.startswith(('/mnt/buildvol/tmp/snyder/', '/mnt/buildvol/SnyderDev/snyder/.scratch-hmr-')):
        path = Path(value)
        if path.is_file() and not any(path.is_relative_to(root) for root in roots.values()):
            files[f'extra/{hashlib.sha256(str(path.parent).encode()).hexdigest()[:12]}/{path.name}'] = path
extra(inventory)
manifest = [{'path': name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': path.stat().st_size} for name, path in sorted(files.items())]
manifest_path = roots['final'] / 'archive-manifest.json'
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
files['archive-manifest.json'] = manifest_path
args.output.parent.mkdir(parents=True, exist_ok=True)
with tarfile.open(args.output, 'w:gz') as archive:
    for name, path in sorted(files.items()):
        archive.add(path, arcname=name, recursive=False)
print(json.dumps({'files': len(files), 'rawBytes': sum(p.stat().st_size for p in files.values()), 'archiveBytes': args.output.stat().st_size, 'sha256': hashlib.sha256(args.output.read_bytes()).hexdigest()}))
