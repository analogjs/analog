from pathlib import Path
import hashlib, json

root = Path('/mnt/buildvol/tmp/snyder/analog-hmr-write-2521')
control_root = Path('/mnt/buildvol/tmp/snyder/analog-hmr-correctness-2521/control')
old_native = Path('/tmp/analog-hmr-p95-2521')
source = Path('/mnt/buildvol/SnyderDev/snyder/analog/.worktrees/hmr-p95-integration-2521')
control_tree = Path('/mnt/buildvol/SnyderDev/snyder/analog/.worktrees/hmr-write-control-2521')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def json_rows(pattern):
    rows=[]
    for path in sorted(root.glob(pattern)):
        row=json.loads(path.read_text())
        rows.append({'path': str(path), 'passed': row.get('passed'), 'errors': row.get('errors', []), 'edits': row.get('edits'), 'actualWindowMs': row.get('actualWindowMs')})
    return rows

matrix = json.loads((root/'qualification/final-matrix-summary.json').read_text())
matrix_pass = [r for r in matrix if r['exitCode'] == 0]
matrix_fail = [r for r in matrix if r['exitCode'] != 0]
native_recheck = json.loads((root/'qualification-native-recheck/metadata.json').read_text())
recheck19 = json.loads((root/'qualification-recheck-19/final-recheck-metadata.json').read_text())
soaks = json_rows('vite*-candidate/valid-soak-r2-*.json')
diagnostics = json_rows('vite*-candidate/ssr-concurrent-diagnostic-*.json')
control_races = json.loads((root/'control-split-races/summary.json').read_text())

inventory = {
  'scope': 'Read-only inventory. It records observed evidence and does not reinterpret an unresolved soak as a harness failure.',
  'finalArtifacts': {
    'candidate': {
      'publishedFixtureHead': '37b6cb9adf179e5b4241a5db597f6747ba4811fa',
      'fixtureCommit': '82926473c5e4be6fc215ffc0e9be2056d00b0995',
      'runtimeSourceTree': '10c9f1d8e470ce49494910d622326fba363bb6dd',
      'tarball': str(root/'candidate-final.tgz'),
      'sha256': sha(root/'candidate-final.tgz'),
      'packLog': str(root/'candidate-final-pack.log'),
    },
    'control': {
      'head': 'e5fef6e050ce7711f4519658df7c8649611aff79',
      'tree': 'c9647c1847143394e9d0385c1a1487c592d28523',
      'base': 'fd8b2890295b396c762d7a7d8e9b6a90759a0ae5',
      'tarball': str(root/'control-final.tgz'),
      'sha256': sha(root/'control-final.tgz'),
      'patch': str(control_root/'final-control-from-fd8b289.patch'),
      'patchSha256': sha(control_root/'final-control-from-fd8b289.patch'),
    },
    'installedArtifactVerification': str(root/'installed-artifact-verification.json'),
    'consumerProvenance': str(root/'consumer-provenance.json'),
  },
  'packedCompatibilityMatrix': {
    'command': f'python3 {root}/run-final-packed-matrix.py --source={source} --tar={root}/candidate-final.tgz --output={root}/qualification --workers=3',
    'metadata': str(root/'qualification/matrix-metadata.json'),
    'summary': str(root/'qualification/final-matrix-summary.json'),
    'originalCount': len(matrix),
    'originalPassed': len(matrix_pass),
    'originalFixtureFailures': matrix_fail,
    'classification': 'The original matrix is 11/13 exit 0. Its two failed fixture probes remain retained; it must not be summarized as 13/13.',
    'correctedRechecks': {
      'angular19SharedOwnerBaseline': {'count': 1, 'metadata': str(root/'qualification-recheck-19/final-recheck-metadata.json'), 'exitCode': recheck19['exitCode']},
      'nativeStyleCases': {'count': len(native_recheck['runs']), 'metadata': str(root/'qualification-native-recheck/metadata.json'), 'allExit0': all(item['exitCode'] == 0 for item in native_recheck['runs']), 'runs': native_recheck['runs']},
      'classification': 'These are later targeted rechecks on the final tar. They correct the two fixture failures but do not alter the original matrix result files.',
    },
  },
  'nativeStyleEvidence': {
    'finalTarTargetedRechecks': {'count': len(native_recheck['runs']), 'metadata': str(root/'qualification-native-recheck/metadata.json'), 'outputs': [str(root/'qualification-native-recheck'/run['consumer']/run['result']) for run in native_recheck['runs']]},
    'earlierBeforeAfterProbeCohort': {
      'summary': str(old_native/'p95-native-summary.json'),
      'count': len(json.loads((old_native/'p95-native-summary.json').read_text())),
      'allExit0': all(row['exitCode'] == 0 for row in json.loads((old_native/'p95-native-summary.json').read_text())),
      'explicitExamples': [str(old_native/name) for name in ['p95-native-old-20.0.0-ngtsc-metadata.json','p95-native-old-20.1.0-ngtsc-auto.json','p95-native-vite6-api-Emulated-auto.json','p95-native-vite8-api-None-auto.json']],
      'classification': 'Earlier cohort; retained as before/after/native behavior evidence and not attributed to candidate-final.tar.',
    },
  },
  'controlFreshness': {
    'command': 'node --expose-gc runtime.mjs --mode=<ngtsc|fast|api> --split-resource-write-ms=50 --race-ssr --edits=2 --ssr-loader=runner --output=<fresh>',
    'summary': str(root/'control-split-races/summary.json'),
    'count': 6,
    'passed': bool(control_races['passed']),
    'classification': 'Vite 6.0 and 8.2 × ngtsc/fast/API against installed control-final. The canonical script invocation logs are retained separately because ESM resolved Vite from the scripts directory; consumer-local byte-identical copies were used for the valid runs.',
  },
  'soaks': {
    'validR2': {
      'launch': str(root/'valid-soak-r2-launch.json'),
      'protocol': {'durationMs': 240000, 'totalTimeoutMs': 300000, 'components': 100, 'edits': 60, 'restartEvery': 20, 'closeQueued': 100},
      'count': len(soaks), 'passed': sum(row['passed'] is True for row in soaks), 'unresolved': sum(row['passed'] is False for row in soaks),
      'outputs': soaks,
      'classification': '8 passed. The Vite 6.0 ngtsc result is unresolved: page.waitForFunction timed out; do not classify it as a harness failure.',
    },
    'stoppedConcurrentDiagnostic': {
      'launch': str(root/'ssr-concurrent-diagnostic-r1-launch.json'),
      'count': len(diagnostics), 'passed': sum(row['passed'] is True for row in diagnostics), 'nonComplete': sum(row['passed'] is not True for row in diagnostics), 'outputs': diagnostics,
      'classification': 'Diagnostic-only concurrent-SSR cohort. All nine are stopped/partial and excluded from acceptance evidence.',
    },
    'wrongCwdInvalid': {
      'declaredCount': 9,
      'reproducerLog': str(root/'wrong-cwd-rejected.log'),
      'classification': 'Invalid provenance cohort, kept separate. The available log demonstrates the consumer-CWD assertion; it is not a product failure or an acceptance result.',
    },
  },
  'unitAndCi': {
    'linuxUnitEvidence': {'log': str(root/'ci-829/linux-vite-8.2.2.log'), 'result': '991 passed, 6 skipped (997); 70 files passed, 2 skipped'},
    'controlLocalEvidence': {'log': str(control_root/'final-package-test.log'), 'result': '960 passed, 6 skipped (966); control correctness-only tree'},
    'classification': 'Counts are recorded with their owning revision/cohort and are not interchangeable.',
  },
  'commands': {
    'matrix': 'run-final-packed-matrix.py with pinned Node 24.15.0 (Node 20.19.5 for Angular <21 consumers), 13 cases, three workers',
    'nativeRecheck': 'compiler-native-style-qualification.mjs with candidate-final.tar; metadata enumerates four exact commands/cases',
    'controlRace': 'consumer-local copy of compiler-runtime-qualification.mjs; flags recorded in controlFreshness.command',
    'validSoak': 'commands per worker are preserved verbatim in valid-soak-r2-launch.json',
  },
}
(root/'evidence-inventory.json').write_text(json.dumps(inventory, indent=2)+'\n')
md = f'''# HMR write qualification evidence inventory

Generated from preserved artifacts. This is an index, not a new measurement.

## Final artifacts

- Candidate: fixture head `37b6cb9`, runtime tree `10c9f1d`, tar SHA-256 `{inventory['finalArtifacts']['candidate']['sha256']}`.
- Control: head `e5fef6e`, tree `c9647c1`, tar SHA-256 `{inventory['finalArtifacts']['control']['sha256']}`.
- Installed-package and lock verification: `{inventory['finalArtifacts']['installedArtifactVerification']}`.

## Packed matrix

The original 13-case packed matrix has **11 exit-0 results and 2 retained fixture failures**: Angular 19.0.1/Vite 6.0 and Angular 22.0.0/Vite 8.2.2. It is not 13/13. The Angular 19 targeted recheck passed, and four native-style targeted rechecks passed; their metadata remains separate from original outputs.

## Races and soaks

- Six installed-control split-write SSR races passed across Vite 6/8 and ngtsc/fast/API.
- Valid r2 soaks: 8 passed; the Vite 6 ngtsc timeout remains unresolved.
- Nine concurrent-SSR diagnostic workers were stopped/partial and are excluded.
- The invalid wrong-CWD cohort is separate; its consumer-CWD assertion log is retained.

## Unit evidence

The Linux Vite 8.2.2 CI log reports 991 passed and 6 skipped. The local correctness-only control test log reports 960 passed and 6 skipped; the counts belong to different source cohorts.

All exact paths, hashes, commands, classifications, and output lists are in `evidence-inventory.json`.
'''
(root/'evidence-inventory.md').write_text(md)
