import { readFile } from 'node:fs/promises';
import { chromium } from 'playwright';
const html=await readFile('failed-ssr.html','utf8');
const b=await chromium.launch(); const p=await b.newPage();
await p.setContent(html.replace('<head>','<head><base href="http://127.0.0.1/">'));
console.log(await p.evaluate(()=>{const e=document.querySelector('[data-message]'); return {style:e?.getAttribute('style'),computed:getComputedStyle(e).getPropertyValue('--fixture-revision'),styles:[...document.styleSheets].map(s=>({href:s.href,rules:[...s.cssRules].map(r=>r.cssText)}))}}));
await b.close();
