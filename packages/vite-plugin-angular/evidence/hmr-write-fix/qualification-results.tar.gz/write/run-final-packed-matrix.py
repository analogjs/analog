#!/usr/bin/env python3
"""Run the Angular 17–22/Vite 6–8 packed compatibility matrix.

The output directory is intentionally fresh. This runner neither reads nor
updates prior HMR qualification cohorts.
"""

import argparse
import concurrent.futures
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import time


CASES = (
    [(angular, '6.0.0') for angular in ('17.3.12', '18.2.14', '19.0.0', '19.0.1', '20.0.0', '20.1.0')]
    + [('21.0.0', '7.0.0')]
    + [('22.0.0', vite) for vite in ('6.0.0', '6.4.3', '7.0.0', '7.3.6', '8.0.0', '8.2.2')]
)
NODE_24 = pathlib.Path('/home/snyder/.local/share/fnm/node-versions/v24.15.0/installation/bin/node')
NODE_20 = pathlib.Path('/home/snyder/.local/share/fnm/node-versions/v20.19.5/installation/bin/node')


def sha256(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', required=True, type=pathlib.Path)
    parser.add_argument('--tar', required=True, type=pathlib.Path)
    parser.add_argument(
        '--output',
        type=pathlib.Path,
        default=pathlib.Path('/mnt/buildvol/tmp/snyder/analog-hmr-write-2521/qualification'),
    )
    parser.add_argument('--workers', type=int, default=3)
    args = parser.parse_args()

    source = args.source.resolve()
    tarball = args.tar.resolve()
    output = args.output.resolve()
    smoke = source / 'packages/vite-plugin-angular/scripts/compiler-vite-smoke.mjs'
    dist = source / 'packages/vite-plugin-angular/dist'
    if not smoke.is_file() or not dist.is_dir():
        parser.error('--source must contain the built vite-plugin-angular package and smoke runner')
    if not tarball.is_file():
        parser.error('--tar must name the packed candidate artifact')
    if any(output.iterdir()):
        parser.error(f'--output must be empty: {output}')
    if not NODE_24.is_file() or not NODE_20.is_file():
        parser.error('pinned Node 24.15.0 and 20.19.5 executables are required')

    output.mkdir(parents=True, exist_ok=True)
    environment = os.environ.copy()
    environment['PATH'] = f'{NODE_24.parent}:{environment["PATH"]}'
    environment['PLAYWRIGHT_SKIP_BROWSER_GC'] = '1'
    revision = subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=source, text=True
    ).strip()
    metadata = {
        'source': str(source),
        'sourceRevision': revision,
        'tarball': str(tarball),
        'tarballSha256': sha256(tarball),
        'node24': subprocess.check_output([NODE_24, '--version'], text=True).strip(),
        'node20': subprocess.check_output([NODE_20, '--version'], text=True).strip(),
        'cases': [{'angular': angular, 'vite': vite} for angular, vite in CASES],
    }
    (output / 'matrix-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')

    def run(case: tuple[str, str]) -> dict[str, object]:
        angular, vite = case
        name = f'final-matrix-{angular}-{vite}'
        log = output / f'{name}.log'
        start = time.time()
        consumer_node = NODE_20 if int(angular.split('.')[0]) < 21 else NODE_24
        with log.open('w') as stream:
            process = subprocess.run(
                [
                    NODE_24,
                    str(smoke.relative_to(source)),
                    f'--angular={angular}',
                    f'--vite={vite}',
                    f'--node-executable={consumer_node}',
                ],
                cwd=source,
                env=environment,
                stdout=stream,
                stderr=subprocess.STDOUT,
            )
        result = {
            'angular': angular,
            'vite': vite,
            'exitCode': process.returncode,
            'elapsedSeconds': time.time() - start,
            'log': str(log),
        }
        print(json.dumps(result), flush=True)
        return result

    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        results = list(pool.map(run, CASES))
    (output / 'final-matrix-summary.json').write_text(json.dumps(results, indent=2) + '\n')
    return int(any(result['exitCode'] for result in results))


if __name__ == '__main__':
    sys.exit(main())
