# Deferred source-barrier regression

Worktree: `/mnt/buildvol/SnyderDev/snyder/analog/.worktrees/hmr-p95-integration-2521`

## Red control

Temporary control: retained the new test and restored only
`compiler-session.ts` to `state.dirty.set(id, beforeCompile)`.

```sh
PATH=/home/snyder/.local/share/fnm/node-versions/v24.15.0/installation/bin:$PATH NX_DAEMON=false NX_NO_CLOUD=true pnpm exec vitest run packages/vite-plugin-angular/src/lib/compiler-session.spec.ts
```

Exit code: `1`

```
Test Files  1 failed (1)
Tests  1 failed | 25 passed (26)
Error: SSR read bypassed the source barrier
  at packages/vite-plugin-angular/src/lib/compiler-session.spec.ts:209:15
```

## Green implementation

Restored:

```ts
state.dirty.set(id, beforeCompile ?? state.dirty.get(id));
```

```sh
PATH=/home/snyder/.local/share/fnm/node-versions/v24.15.0/installation/bin:$PATH NX_DAEMON=false NX_NO_CLOUD=true pnpm exec vitest run packages/vite-plugin-angular/src/lib/compiler-session.spec.ts
```

Exit code: `0`

```
Test Files  1 passed (1)
Tests  26 passed (26)
Duration  638ms
```

`pnpm nx run vite-plugin-angular:typecheck` also passed before the test-only
strengthening; the implementation source was unchanged afterward. `git diff
--check` passed after restoration.
