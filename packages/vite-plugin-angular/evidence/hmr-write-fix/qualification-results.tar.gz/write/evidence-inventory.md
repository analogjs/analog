# HMR write qualification evidence inventory

Generated from preserved artifacts. This is an index, not a new measurement.

## Final artifacts

- Candidate: fixture head `37b6cb9`, runtime tree `10c9f1d`, tar SHA-256 `d583ff5ade868f095747ab07d3dbc16767029c09a49ba260439eadf127f6525b`.
- Control: head `e5fef6e`, tree `c9647c1`, tar SHA-256 `19215320d5bbc5d701238f5a2aa114b24763710b1d6908d8dbf6d09974271717`.
- Installed-package and lock verification: `/mnt/buildvol/tmp/snyder/analog-hmr-write-2521/installed-artifact-verification.json`.

## Packed matrix

The original 13-case packed matrix has **11 exit-0 results and 2 retained fixture failures**: Angular 19.0.1/Vite 6.0 and Angular 22.0.0/Vite 8.2.2. It is not 13/13. The Angular 19 targeted recheck passed, and four native-style targeted rechecks passed; their metadata remains separate from original outputs.

## Races and soaks

- Six installed-control split-write SSR races passed across Vite 6/8 and ngtsc/fast/API.
- Valid r2 soaks: 8 passed; the Vite 6 ngtsc timeout remains unresolved.
- Nine concurrent-SSR diagnostic workers were stopped/partial and are excluded.
- The invalid wrong-CWD cohort is separate; its consumer-CWD assertion log is retained.

## Unit evidence

The Linux Vite 8.2.2 CI log reports 991 passed and 6 skipped. The local correctness-only control test log reports 960 passed and 6 skipped; the counts belong to different source cohorts.

All exact paths, hashes, commands, classifications, and output lists are in `evidence-inventory.json`.
