# PR 2521 CI snapshot: 2026-09-08

Snapshot source: `gh pr view 2521 --repo analogjs/analog --json ...` at
2026-09-08 UTC. The checked head is `82926473c5e4be6fc215ffc0e9be2056d00b0995`.

The only failed checks are both Angular 22.0.0 / Vite 8.2.2 consumer jobs in
[Compiler Compatibility Tests](https://github.com/analogjs/analog/actions/runs/34190962222):

* [Linux job 101948761402](https://github.com/analogjs/analog/actions/runs/34190962222/job/101948761402)
* [Windows job 101948761606](https://github.com/analogjs/analog/actions/runs/34190962222/job/101948761606)

Both terminate in the same API Emulated external native-style test command and
the same obsolete assertion: `native-styles.mjs:246`, actual parent text `0`,
expected literal `1`. This is the third CSS cycle after a permitted template
fallback reload. The worker at this CI head does not return `parent` in the
captured `before` state and therefore compares to a value that the earlier
template fallback may reset.

The local corrected worker captures `before.parent`, compares the CSS result to
that capture, records each CSS-phase event slice, and rejects metadata updates
or full reloads during native CSS. Its packed-consumer recheck passed on Vite
8.2.2 API Emulated/None and ngtsc Emulated, plus Vite 7.3.6 API Emulated.
That worker is not committed in `82926473`; these CI failures are expected to
remain until its test-only commit is published.

This is distinct from the prior Windows-only bootstrap failure retained in
`prior-windows-bootstrap.log`: it reached API Emulated and None, then API
ShadowDom timed out after 30 seconds at initial `[data-style]` visibility in
`styles.mjs:82`, before an edit. The current Windows failure is not that
unreproduced lifecycle failure; it is the deterministic native parent
assertion, after compilation/runtime/style work has already run.
