# Runner pending-fetch generation race

The native reproduction is
`/mnt/buildvol/tmp/snyder/analog-hmr-barrier-2521/vite6-runner-cache-race.mjs`.
It creates a runnable SSR environment, makes a transform read generation 9 and
pause, invalidates that module after writing generation 10, then imports the
same entry again before the first fetch finishes. The probe wraps the public
`environment.fetchModule` method: after the original fetch settles, it retries
when that returned module still has `moduleGraph.invalidationState`.

```sh
for consumer in vite6-candidate vite6-latest-candidate vite7-candidate vite8-candidate; do
  VITE_ROOT=/mnt/buildvol/tmp/snyder/analog-hmr-barrier-2521/$consumer \
  PATH=/home/snyder/.local/share/fnm/node-versions/v24.15.0/installation/bin:$PATH \
  node /mnt/buildvol/tmp/snyder/analog-hmr-barrier-2521/vite6-runner-cache-race.mjs
done
```

Observed output:

```text
{"vite":"6.0.0","old":10,"current":10,"fresh":10}
{"vite":"6.4.3","old":10,"current":10,"fresh":10}
{"vite":"7.3.6","old":10,"current":10,"fresh":10}
{"vite":"8.2.2","old":10,"current":10,"fresh":10}
```

Without the wrapper, the same held fetch returns `old:9`, `current:9`, and
`fresh:10`; calling `runner.clearCache()` does not change the pending result.
`ModuleRunner.cachedModule()` retains those promises by URL until the initial
fetch settles. Vite main retains that implementation:
`packages/vite/src/module-runner/runner.ts`, lines 42-45 and 205-221, fetched
2026-09-08 from `vitejs/vite` main.

The public fetch retry observes the graph state associated with the returned
module, rather than a process-wide generation counter, runner internals, or a
second work queue. It preserves native server HMR and makes a shared pending
runner import resolve the newest generation.
