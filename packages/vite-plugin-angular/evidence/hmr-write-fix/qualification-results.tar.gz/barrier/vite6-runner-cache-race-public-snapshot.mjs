import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
const viteRoot =
  process.env['VITE_ROOT'] ??
  '/mnt/buildvol/tmp/snyder/analog-hmr-barrier-2521/vite6-candidate';
const { createRunnableDevEnvironment, createServer, version } = await import(
  `${viteRoot}/node_modules/vite/dist/node/index.js`
);

const root = await mkdtemp(join(tmpdir(), 'vite6-runner-race-'));
const entry = join(root, 'entry.js');
const style = join(root, 'style.txt');
const started = Promise.withResolvers();
const release = Promise.withResolvers();
let hold = false;
let server;
try {
  await writeFile(entry, 'export const revision = -1;');
  await writeFile(style, '0');
  server = await createServer({
    root,
    configFile: false,
    logLevel: 'silent',
    environments: {
      ssr: { dev: { createEnvironment: createRunnableDevEnvironment } },
    },
    plugins: [
      {
        name: 'slow-compiled-entry',
        async transform(_code, id) {
          if (id !== entry) return;
          const revision = await readFile(style, 'utf8');
          if (hold) {
            started.resolve();
            await release.promise;
          }
          return `export const revision = ${revision};`;
        },
      },
    ],
  });
  await server.listen();
  const environment = server.environments.ssr;
  const runner = environment.runner;
  const fetchModule = environment.fetchModule.bind(environment);
  const graph = environment.moduleGraph;
  const invalidateModule = graph.invalidateModule.bind(graph);
  const invalidations = new WeakMap();
  let generation = 0;
  graph.invalidateModule = function (module, ...args) {
    invalidations.set(module, ++generation);
    return invalidateModule(module, ...args);
  };
  environment.fetchModule = async function (id, importer, options) {
    let retry = false;
    for (;;) {
      const started = generation;
      const result = await fetchModule(
        id,
        importer,
        retry ? { ...options, cached: false } : options,
      );
      const module =
        'id' in result && typeof result.id === 'string'
          ? graph.getModuleById(result.id)
          : 'cache' in result
            ? await graph.getModuleByUrl(id)
            : undefined;
      if (!module || (invalidations.get(module) ?? 0) <= started) {
        return retry && !('externalize' in result)
          ? { ...result, invalidate: true }
          : result;
      }
      retry = true;
    }
  };
  assert.equal((await runner.import('/entry.js')).revision, 0);

  hold = true;
  await writeFile(style, '9');
  const module = graph.getModuleById(entry);
  assert.ok(module, 'entry is in the SSR graph');
  graph.invalidateModule(module);
  const oldGeneration = runner.import('/entry.js');
  await started.promise;

  await writeFile(style, '10');
  graph.invalidateModule(module);
  const currentGeneration = runner.import('/entry.js');
  release.resolve();
  const [oldResult, currentResult] = await Promise.all([
    oldGeneration,
    currentGeneration,
  ]);
  const fresh = await runner.import('/entry.js');
  console.log(
    JSON.stringify({
      vite: version,
      old: oldResult.revision,
      current: currentResult.revision,
      fresh: fresh.revision,
    }),
  );
  assert.equal(oldResult.revision, 10);
  assert.equal(currentResult.revision, 10);
  assert.equal(fresh.revision, 10);
} finally {
  await server?.close();
  await rm(root, { recursive: true, force: true });
}
