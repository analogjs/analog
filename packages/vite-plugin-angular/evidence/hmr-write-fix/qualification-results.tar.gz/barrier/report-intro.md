# HMR write-race repair and p95 qualification

This follow-up to `HMR_P95_SPRINT.md` uses a new source revision and a new correctness-only control. Earlier cohorts, their failures and their 6/12 browser-cell result remain historical; no samples are replaced or pooled.

## Source changes

A split save can expose an empty stylesheet between truncate and write. The shared-style reproduction held that interval open for 25 ms. Angular's compiler treats an empty Emulated stylesheet as having no styles and can select None encapsulation, explaining the missing CSS and `_ngcontent` attributes. Client HMR now awaits Vite's stable `ctx.read()`. Server watcher callbacks synchronously publish compiler dirtiness and a source-write gate before invalidating the module graph. Normal nonempty reads incur no polling delay; an observed zero-byte source is polled for at most 100 ms, so deliberate empty resources remain supported. Close aborts waiting gates and drains already-admitted native compilation.

An additional deterministic regression found that a duplicate ungated invalidation could erase a pending gate for the same file. The session now retains that gate until admission, while a newly supplied gate supersedes it. The test fails against the previous implementation with `SSR read bypassed the source barrier`, then passes with the fix. It does not establish that this was the cause of every historical timeout.

Two bounded optimizations remain in the candidate: style-HMR AST traversal visits the top-level statements containing metadata replacement calls, and the ngtsc resource branch suppresses redundant Vite module re-evaluation after dispatching its complete custom metadata update. Behavioral TypeScript edits and Angular 19 reload fallbacks retain their existing paths. The control receives the correctness repairs without these optimizations, lazy Effect allocation, subpath loading, SSR warming or native stylesheet adoption.

## Qualification boundaries

Native CSS assertions now capture parent state immediately before each CSS edit. A permitted template reload can reset that state between CSS phases. Each qualified native edit must still preserve DOM identity, focus, selection and nested state, and must emit neither metadata replacement nor full reload. This fixes the test baseline without weakening the native CSS contract. Templates, ordinary metadata styles and explicit reload fallbacks do not gain a DOM-preservation guarantee.

Runtime workers reject a working directory different from the copied worker's installed consumer and assert the rendered Angular version. Vite selects its bound port directly, avoiding the old reserve-close-listen race. A failed SSR CSS assertion now captures the actual SSR response, its separately rendered page, source CSS and computed style before closing that page; the old outer catch captured only the client page.

## Historical failures retained

- The preceding source's valid nine-cell soak cohort passed eight cells and timed out checking Vite 6/ngtsc SSR CSS at revision 5. Its client-page snapshot cannot establish SSR freshness. A separate concurrent diagnostic captured 992 SSR renders with matching source CSS, inline SSR CSS and computed styles; it did not reproduce that timeout. One diagnostic cell failed before startup because of the port-reservation race. None of these samples is replaced by the final cohort.
- An earlier wrong-working-directory cohort is excluded as invalid setup, including its passing cells. Stopped partial setup runs remain incomplete evidence.
- The preceding packed matrix had 11/13 successful exits. Angular 19's empty-style test and Vite 8/API native CSS test used state baselines from before permitted reloads. Their failures and corrected targeted rechecks remain separate. The Linux and Windows CI failures at `82926473` were the same native-fixture baseline, not bootstrap failures.
- The older Windows API ShadowDom initial-render timeout remains unreproduced. Current passing checks qualify their recorded revision; they do not establish a cause for that historical failure.

## Protocol

The original maximum 5% regression limits apply independently to browser template/CSS medians and nearest-rank p95, and to first/warm build medians. The fixed cohort uses 15 fresh build processes per side/mode, five fresh browser processes per side/Vite/mode with 25 edit pairs each, and three fresh SSR-idle processes per mode/interval/startup-order/warmup setting. First edits remain included. Workers run serially after owned correctness work finishes; unrelated host services remain running and host load is sampled. All eight consumers retain identical transitive pins after only tarball path/integrity substitution.

Four-minute soak windows have a hard five-minute process cap. These are bounded concurrency/restart/shutdown checks, not leak-freedom claims. Warming still trades speculative CPU after actual SSR use for lower foreground request latency; `experimental.ssrHmrWarmup: false` preserves on-demand behavior. `experimental.componentStyleHmr: 'metadata'` preserves the compatibility path. Effect remains a direct `4.0.0-rc.112` prerelease dependency with Schema; subpath loading does not reduce installation size.
