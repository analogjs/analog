# Barrier packed recheck

Date: 2026-09-08 UTC

Candidate package: `candidate-barrier.tgz`

* SHA-256: `b3652232dffe5297cdf7248ed0a28e21a70178a8194dd8f8421d848f8aacd101`
* source head: `61090461a75738a072cba8cb071251013b0d5464`
* runtime source tree: `31ca07f5a7b7bc0411f5e0317314ea58bd1f7408`
* corrected native worker SHA-256: `9b4a9376bf0ddd4d57436b95262ef33539023ef0a52d55686c8c009fe8f7fd56`

The scratch runner copies the exact candidate tarball into each fresh consumer,
then runs the current integration fixture scripts with Node 24.15.0:

```text
node runner.mjs --angular=22.0.0 --vite=6.0.0 --node-executable=.../node
node runner.mjs --angular=22.0.0 --vite=8.2.2 --node-executable=.../node
```

Both consumers contain a tarball with the candidate SHA above. The Vite 6.0
consumer completed its browser fixture and ngtsc, fast, and API runtime
qualifications without assertion/error output. The Vite 8.2.2 consumer contains
23 `runtime-*.json` results, each with `passed: true`, and `style-result.json`
is passed for all nine mode/encapsulation rows. Its native-style matrix includes
the corrected API external Emulated and None cases and has no failed artifact or
runner assertion/error output.

Runner source: `runner.mjs` SHA-256
`43ff701f76f08d5c5850bcb2474056bbb1c5f9d02110644cd348ab47b6a0d247`.
It is a scratch-only adaptation of the fixture runner: it selects the explicit
candidate tarball and writes consumers below this directory.
