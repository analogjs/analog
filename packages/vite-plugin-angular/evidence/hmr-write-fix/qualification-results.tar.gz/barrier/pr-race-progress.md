### Write-race repair progress — 2026-09-08 06:10 UTC

| Workstream | Progress | Disposition |
| --- | --- | --- |
| Shared-style root cause and repair | `██████████` **1/1** | Deterministic split-write reproduction; source fix published |
| Package gates | `██████████` **6/6** | 992 tests, typechecks, lint, format and build pass |
| Correctness acceptance | `░░░░░░░░░░` **0/1** | Blocked: actual Vite 6/ngtsc SSR output retained prior CSS during a new resource read; plain-JS runner pending-fetch race reproduced |
| Browser cells meeting all limits | `█████░░░░░` **6/12** | Previous completed cohort; new comparison follows correctness |
| Final CI | `░░░░░░░░░░` **0/1** | Linux/Windows Vite 8.2.2 passed at `61090461a`; native Vite 6 race remains separate |

The new candidate also narrows style-HMR AST traversal and removes redundant ngtsc resource module re-evaluation. Performance claims await a separate fixed cohort with the original 5% limits; historical samples are preserved.

<a id="user-content-benefits"></a>

## Benefits

- ✅ **Correct SSR invalidation:** loaded owner/query variants and importers are invalidated with file timestamps; known unloaded owners retain unrelated modules, and old pending transforms cannot satisfy newer reads or overwrite newer results.
- ✅ **Automatic fast behavioral reloads:** methods, fields, constructors, changed dependencies, directives, pipes and ambiguous edits reload with current behavior. Proven template/style-only changes retain metadata HMR.
- ✅ **Lower loading/allocation costs:** Effect subpaths, lazy independent runtimes, correct empty include reuse, shared fast ASTs only for unchanged source, and once-per-compilation API diagnostic normalization. Import, construction and build measurements remain separate.
- ✅ **Optional warming after SSR use:** a scoped 75 ms quiet-period task after client compilation/update settlement, immediate read bypass, failure/recovery visibility and cancellation/drain/restart proof. Unused SSR, builds, tests and disabled host HMR do not speculate.
- ✅ **Qualified native CSS preservation:** existing integration externalization updates recorded non-ShadowDom usages with DOM identity, focus, selection and nested child state preserved in dedicated fixtures. Ordinary styles retain metadata updates.
- ✅ **Focused correctness qualification:** 992 package tests, typechecks, lint/build/artifact gates, all six native SSR split-write probes and the packed matrix with targeted fixture rechecks pass. Overall correctness acceptance remains open because one of nine new soak cells failed.

**Published head:** `61090461a75738a072cba8cb071251013b0d5464`. The measurements immediately below retain their recorded previous source identities. **Measured candidate source tree:** `b3edbd16cb4c8dd323d976cba072d852fff26860`. **Repaired control:** `2283861272f094b0773841bb10895502f88c8235`. Source patches and exact tarballs are archived; the final publication preserves the measured source tree. [Current report](https://github.com/benpsnyder/analog/blob/6df41ba6421c8cbebd2d9de4c7f809b35ceb510a/packages/vite-plugin-angular/HMR_P95_SPRINT.md), [maintainer points](https://github.com/benpsnyder/analog/blob/6df41ba6421c8cbebd2d9de4c7f809b35ceb510a/PointsForBrandon.md).

<a id="user-content-known-published-head-issues"></a>

## Correctness defects and disposition

**The split-save shared-style defect and duplicate-invalidation gate loss are fixed and published. Correctness acceptance remains blocked by a newly captured native Vite 6 SSR race.** At `61090461a`, a watcher-boundary read returned template revision 10 with CSS revision 9 while the source contained revision 10. The actual SSR response and computed style now establish the defect; prior outer client-page captures could not. A separate plain-JavaScript Vite 6 runner reproduction returns an older pending fetch to a newer import after graph invalidation (`old: 9, current: 9, fresh: 10`). A bounded server-resource HMR correction is being tested. No passing rerun replaces either failed soak.

The split-write repair uses Vite's stable client read and abortable source-write gates in the existing compiler scheduler; ungated duplicate invalidations retain pending gates. All 992 package tests, the final six native SSR split-write probes, focused packed consumers, and Linux/Windows Vite 8.2.2 CI pass. Native CSS rechecks preserve DOM identity, focus, selection and child state with no metadata/reload event during CSS edits. These focused passes do not resolve the separately reproduced native SSR race.

The prior Windows API ShadowDom initial-render timeout remains unreproduced. New fixture diagnostics capture browser, requests, server errors and HTML if it recurs. Previous failures remain retained; current CI and qualification determine the final disposition.

The published SSR query/pending-transform defects, unrelated-module eviction and fast stale-class behavior are fixed. Shared Sass fallback freshness, renderer cache invalidation for destroyed components and Angular 19 metadata replay remain qualified correctness fixes.

**The strict 5% acceptance gate remains unmet: 6/12 browser cells pass all four latency limits; first/warm build gates pass. The latency misses are detailed below. No overall speedup or completed performance-acceptance claim is made.**

The historical original-control failure after 17 edit pairs remains retained. Four additional original 100-pair runs and two renderer-repaired diagnostic runs did not reproduce it. The final control also passed fast/ngtsc 25-pair checks after a fairness repair removed control-only post-transform parsing. This supports the backport's behavior, but does not establish elimination of the intermittent failure. New comparison failures, if any, remain unavailable cells rather than replacement samples. [Control provenance and boundaries](https://github.com/benpsnyder/analog/blob/6df41ba6421c8cbebd2d9de4c7f809b35ceb510a/packages/vite-plugin-angular/HMR_P95_SPRINT.md#revisions-and-fair-control-repair).

<a id="user-content-tradeoffs-and-cautions"></a>

## Tradeoffs and cautions

- ⚠️ **Performance acceptance uses the original limits.** Each browser median/p95 and each first/warm build median must remain within 5%. The complete fixed cohort and its disposition appear below; previous failed cohorts remain historical and unaccepted.
- ⚠️ **Warming trades background CPU for foreground request latency.** A used SSR compiler may warm without another request. Independent server startup remains, and fast mode shows no consistent benefit. `experimental.ssrHmrWarmup: false` preserves on-demand compilation. Update settlement does not claim browser paint completion.
- ⚠️ **Metadata HMR recreates views.** It cannot guarantee focus, selection, DOM identity or child-state preservation. `experimental.componentStyleHmr: 'metadata'` remains an escape hatch. ShadowDom, missing identity, unsupported versions and failed updates retain reload fallbacks.
- ⚠️ **Effect remains a direct prerelease Node dependency.** Version `4.0.0-rc.112`, Schema, installation footprint and maintenance vocabulary remain. Subpaths reduce loaded code, not installed contents; the comparison does not isolate Effect's contribution.
- ⚠️ **Evidence is bounded.** Short soaks qualify four-minute update windows within five-minute processes, not leak freedom. Measurements run serially on a shared host with unrelated services preserved and load recorded; they are not a statistical confidence guarantee.

Implementation evidence belongs here; the adoption decision remains in [analogjs/analog#2519](https://github.com/analogjs/analog/issues/2519).

<a id="user-content-pr-checklist"></a>

## PR Checklist

Tracks [analogjs/analog#2519](https://github.com/analogjs/analog/issues/2519). The PR remains a draft pending maintainer review. Measurements, migrations and validation belong here; the issue retains the adoption rationale, alternatives and decision.

<a id="user-content-affected-scope"></a>

## Affected scope

- Primary: `vite-plugin-angular` compiler composition and HMR.
- Supporting compatibility work from [analogjs/analog#2520](https://github.com/analogjs/analog/pull/2520): roots, HMR metadata, declarations and Node bootstrap; reconcile overlapping work when merged.
- Source-map handling adapted from [analogjs/analog#2506](https://github.com/analogjs/analog/pull/2506), preserving Vite map settings and source positions.
- The `platform` no-SSR route-header repair is separately attributed supporting work; updating only `@analogjs/vite-plugin-angular` does not ship it.

<a id="user-content-compiler-design-and-public-boundary"></a>

## Compiler design and public boundary

`CompilerSession` owns listeners, native callers, resources and its lazy runtime. Close cancels waiting warmup, drains admitted native work, then disposes resources. `CompilationScheduler` serializes compilation/lazy emission, coalesces pending files and holds reads behind the latest successful generation. Client, server and restarted configurations keep independent runtimes and memoization ownership; dependency scans cannot own a live compiler.

`CompilerBackend`, `CompilerSourceGraph`, `StylesheetCompiler`, `DependencyTransformer` and `CacheStorage` expose replaceable capabilities. Source/test TypeScript retains checked optional/indexed access. `angular(options): Plugin[]` remains native; packed root declarations pass with `skipLibCheck: false`, and checked browser/application graphs exclude Effect. Shipped internal declarations still contain Effect types. Pure compiler algorithms and synchronous TypeScript host callbacks remain native.

Existing transform-memory limits remain 256 entries / 64 MiB with toolchain namespaces and no-replace disk publication. ENOENT is a miss; other failures remain visible. `ANALOG_TRANSFORM_CACHE=0` disables disk persistence. No general discovery cache or cross-generation emit cache was added. Phase timers cover native compilation, integration discovery, includes and tsconfig parsing.

[Session tests](https://github.com/benpsnyder/analog/blob/e66dfc92058e49c89efa722b88a9b0300a4a2707/packages/vite-plugin-angular/src/lib/compiler-session.spec.ts), [scheduler tests](https://github.com/benpsnyder/analog/blob/e66dfc92058e49c89efa722b88a9b0300a4a2707/packages/vite-plugin-angular/src/lib/compilation-scheduler.spec.ts), [restart tests](https://github.com/benpsnyder/analog/blob/e66dfc92058e49c89efa722b88a9b0300a4a2707/packages/vite-plugin-angular/src/lib/restartable-plugins.spec.ts), [implementation record](https://github.com/benpsnyder/analog/blob/6df41ba6421c8cbebd2d9de4c7f809b35ceb510a/packages/vite-plugin-angular/HMR_INTEGRATION.md#correctness-and-ownership).

<a id="user-content-behavior-and-code-paths"></a>

## Behavior and code paths

| Path | Result | Limit or fallback |
| --- | --- | --- |
| SSR resource/source edit | Publish dirtiness synchronously; invalidate every loaded owner variant/importer with file timestamps; reads use the latest generation. | Known unloaded owners retain unrelated modules. Unknown ownership retains whole-graph invalidation. Native analysis remains program-wide. |
| SSR warmup | Only a real development SSR read qualifies. One session-scoped `Effect.sleep(75)` fiber follows settled client work; edits replace it and the existing scheduler coalesces work. | Reads bypass the delay; background failures remain observable; later edits recover. Close cancels waiting work and drains admitted work. Host HMR settings control eligibility. |
| Ordinary styles | ngtsc, fast and Compilation API retain metadata HMR. | Automatic externalization missed template-latency gates. Focus, selection, nodes and child views are not preserved by contract. |
| Existing integration externalization with `auto` | Native updates for ngtsc / Angular 20–22 / Vite 6–8 and API / Angular 21–22 / Vite 7–8. Existing link ownership and every shared usage stay current. | ShadowDom, unsupported capability, missing identity and failed load retain fallbacks. Explicit `metadata` refreshes sources before a compatibility reload. |
| Fast TypeScript edit | AST comparison permits only proven literal template/style changes to use metadata replacement. | Behavioral/dependency/directive/pipe/ambiguous changes reload automatically; no donor-prototype copying. |
| Angular 19 shared resources | Refresh and reload, suppressing metadata replay during that transition. | Full reload resets state; Angular 19.0.0 retains its upstream-runtime fallback. |

```ts
angular({
  experimental: {
    ssrHmrWarmup: false,
    componentStyleHmr: 'metadata',
  },
});
```

Sass/Less/PostCSS continue through Vite preprocessing and dependency tracking. Existing integration requests, including detected Tailwind Vite integration, remain respected. [Migration guide](https://github.com/benpsnyder/analog/blob/6df41ba6421c8cbebd2d9de4c7f809b35ceb510a/apps/docs-analog/src/content/guides/migrating-v2-to-v3.md#development-updates-and-component-styles).

<a id="user-content-hmr-benchmarks"></a>

## Current build and HMR measurements

**Current fixed cohort:** candidate base `e64b7d012fb6778b31e03f9581393c11d19b870d` plus the archived patch, source tree `b3edbd16cb4c8dd323d976cba072d852fff26860`; repaired control `2283861272f094b0773841bb10895502f88c8235`. The control backports equivalent renderer invalidation and the direct fast helper path without Effect loading/lifecycle optimizations, warming or native CSS. Source patches, exact packed artifacts, worker hashes and pinned locks are archived. Earlier cohorts are separate.

Builds: 15 fresh processes per side/mode, 20 components, three builds each, alternating order and explicit GC with all three closed plugin sets retained. Values are process medians.

| Mode | Import ms | Construction ms | First build ms | Warm build ms | First/warm gate |
| --- | --- | --- | --- | --- | --- |
| ngtsc | 728.1 → 652.2 (-10.4%) | 5.2 → 5.1 (-1.9%) | 892.4 → 899.7 (+0.8%) | 566.4 → 563.1 (-0.6%) | Pass |
| fast | 724.2 → 646.5 (-10.7%) | 5.3 → 5.1 (-2.9%) | 239.3 → 249.0 (+4.0%) | 146.4 → 145.2 (-0.8%) | Pass |
| api | 722.4 → 646.5 (-10.5%) | 5.4 → 5.2 (-2.4%) | 1567.2 → 1559.0 (-0.5%) | 1132.1 → 1145.0 (+1.1%) | Pass |

| Mode | Import heap MiB control / candidate | Retained heap MiB control / candidate | Import CPU ms control / candidate | First build CPU ms control / candidate | Warm build CPU ms control / candidate |
| --- | --- | --- | --- | --- | --- |
| ngtsc | 40.4 / 36.6 | 57.3 / 53.6 | 983.3 / 880.3 | 2969.8 / 3076.3 | 2080.2 / 2128.7 |
| fast | 40.4 / 36.6 | 49.9 / 46.2 | 972.7 / 861.1 | 1137.2 / 1185.8 | 1136.9 / 1069.8 |
| api | 40.4 / 36.6 | 61.6 / 58.0 | 949.0 / 862.8 | 3790.5 / 3782.2 | 3427.0 / 3315.3 |

Browser HMR: five fresh processes × 25 template/CSS pairs per side/mode/Vite; pooled medians and nearest-rank p95 including first edits. DOM/style listeners are armed before writes. No manual SSR graph refresh; no paint claim or counter-only DOM-preservation claim. Failed samples are retained.

| Mode / Vite | Template median / p95 ms control → candidate | CSS median / p95 ms control → candidate | Largest regression | Gate |
| --- | --- | --- | --- | --- |
| ngtsc / 6 | 39.0 / 50.2 → 39.1 / 90.7 | 32.6 / 51.9 → 33.2 / 53.3 | +80.8% | **Miss** |
| ngtsc / 6-latest | 39.5 / 47.8 → 39.1 / 48.3 | 34.0 / 52.7 → 33.9 / 54.1 | +2.7% | Pass |
| ngtsc / 7 | 38.9 / 52.4 → 38.8 / 48.0 | 33.4 / 50.6 → 34.0 / 53.4 | +5.5% | **Miss** |
| ngtsc / 8 | 39.6 / 46.8 → 38.8 / 48.2 | 32.9 / 38.4 → 32.0 / 42.9 | +11.8% | **Miss** |
| fast / 6 | 25.6 / 28.9 → 24.7 / 28.5 | 17.6 / 20.1 → 17.9 / 20.6 | +2.7% | Pass |
| fast / 6-latest | 25.5 / 29.3 → 25.0 / 29.8 | 17.9 / 20.7 → 17.6 / 20.1 | +1.6% | Pass |
| fast / 7 | 25.0 / 28.6 → 24.9 / 30.0 | 17.5 / 20.3 → 17.5 / 20.7 | +4.9% | Pass |
| fast / 8 | 25.5 / 28.7 → 25.7 / 28.9 | 17.7 / 19.9 → 17.6 / 21.0 | +5.5% | **Miss** |
| api / 6 | 47.2 / 75.9 → 47.9 / 81.1 | 43.9 / 57.3 → 43.4 / 50.2 | +6.9% | **Miss** |
| api / 6-latest | 47.6 / 68.6 → 48.4 / 74.2 | 45.4 / 56.2 → 48.1 / 57.5 | +8.0% | **Miss** |
| api / 7 | 46.0 / 74.4 → 45.9 / 74.3 | 42.2 / 54.3 → 44.3 / 54.4 | +4.9% | Pass |
| api / 8 | 47.8 / 76.7 → 47.6 / 71.8 | 48.1 / 57.2 → 46.2 / 56.3 | -0.5% | Pass |

Each complete cell has 125 edits per side. Failed workers are retained without replacement and make their complete comparison cell unavailable. The summary records incomplete cells and completed-edit counts. This latency fixture checks the component counter; the separate native-style fixture establishes DOM identity/focus/selection/child-state preservation. First SSR, CPU and Node peak RSS remain in the raw worker JSON; the summary aggregates complete comparison cells only.


**The strict 5% acceptance gate remains unmet: 6/12 browser cells pass all four latency limits; first/warm build gates pass. The latency misses are detailed below. No overall speedup or completed performance-acceptance claim is made.**

Node CPU/RSS exclude Chromium and native child processes. [Full protocol, foreground SSR, CPU/memory and raw archive](https://github.com/benpsnyder/analog/blob/6df41ba6421c8cbebd2d9de4c7f809b35ceb510a/packages/vite-plugin-angular/HMR_P95_SPRINT.md#performance-results-and-acceptance).

<a id="user-content-larger-fixtures-and-sustained-qualification"></a>

## SSR idle intervals and new sustained qualification

SSR groups have three fresh processes per flag/startup order/interval/mode, 100 components and five pairs. Fixed 0/250/1000 ms waits follow frame-polled browser assertions. Server-first renders after Vite listens and before browser navigation; browser-first navigates first. Neither is total process startup time, and these browser assertions are not pooled with DOM-event latencies.

| Mode | Idle ms | Startup order | Foreground SSR median / p95 ms, off → default | First SSR ms, off / default | Node CPU ms, off / default | Node peak RSS MiB, off / default |
| --- | --- | --- | --- | --- | --- | --- |
| ngtsc | 0 | browser | 90.3 / 129.7 → 87.4 / 127.8 | 1169.9 / 1161.4 | 17067.7 / 17149.5 | 1315.3 / 1282.5 |
| ngtsc | 0 | server | 82.5 / 112.9 → 81.7 / 121.2 | 1728.0 / 1702.9 | 16870.8 / 16802.6 | 1302.7 / 1308.8 |
| ngtsc | 250 | browser | 104.3 / 131.0 → 34.6 / 46.5 | 1158.9 / 1184.8 | 17460.9 / 17749.4 | 1301.5 / 1320.0 |
| ngtsc | 250 | server | 101.2 / 141.2 → 35.7 / 52.0 | 1777.0 / 1754.3 | 18111.8 / 17856.7 | 1319.6 / 1305.6 |
| ngtsc | 1000 | browser | 112.6 / 157.7 → 41.9 / 61.7 | 1152.1 / 1174.5 | 17345.2 / 17744.0 | 1315.2 / 1305.2 |
| ngtsc | 1000 | server | 114.6 / 176.1 → 48.4 / 57.7 | 1717.0 / 1776.7 | 18210.3 / 17671.9 | 1317.1 / 1285.1 |
| fast | 0 | browser | 40.3 / 52.8 → 41.9 / 53.2 | 780.4 / 758.6 | 9806.8 / 9383.7 | 1086.4 / 1088.1 |
| fast | 0 | server | 38.2 / 49.3 → 40.4 / 48.5 | 1298.1 / 1311.4 | 9831.5 / 9884.7 | 1093.5 / 1098.0 |
| fast | 250 | browser | 58.6 / 77.8 → 60.5 / 77.6 | 781.8 / 789.0 | 9970.5 / 10286.1 | 1043.7 / 1079.9 |
| fast | 250 | server | 61.7 / 72.5 → 65.1 / 77.7 | 1320.7 / 1287.2 | 10088.9 / 9706.0 | 1078.2 / 1064.5 |
| fast | 1000 | browser | 67.5 / 83.9 → 65.4 / 81.1 | 793.9 / 785.5 | 9751.7 / 10411.6 | 1056.8 / 1098.1 |
| fast | 1000 | server | 66.1 / 81.4 → 60.5 / 81.2 | 1297.3 / 1304.5 | 9771.5 / 9957.6 | 1087.1 / 1081.7 |
| api | 0 | browser | 226.1 / 345.9 → 224.5 / 328.7 | 1874.6 / 1894.1 | 22808.8 / 23097.6 | 1880.2 / 1858.3 |
| api | 0 | server | 220.8 / 309.4 → 224.0 / 317.6 | 1966.6 / 1942.7 | 22033.4 / 22961.6 | 1916.1 / 1820.7 |
| api | 250 | browser | 222.3 / 334.6 → 47.2 / 96.5 | 1894.2 / 1868.1 | 21629.4 / 21463.0 | 1805.3 / 1775.5 |
| api | 250 | server | 225.1 / 304.9 → 42.0 / 121.3 | 1946.6 / 1926.4 | 21148.6 / 22208.2 | 1767.6 / 1889.0 |
| api | 1000 | browser | 207.0 / 339.2 → 50.1 / 62.3 | 1862.8 / 1908.9 | 22172.3 / 21585.5 | 1832.4 / 1885.6 |
| api | 1000 | server | 236.9 / 329.4 → 42.6 / 59.5 | 1954.4 / 1994.9 | 22480.4 / 22902.7 | 1903.9 / 1904.1 |

**Previous cohort, retained separately — nine short soaks passed:** 540 edit pairs, 27 restarts and 900 queued callers drained. Each has a 240,000 ms update window and 300,000 ms total process timeout; observed process times were 243.9–249.0 seconds. Vite 6.0 uses the Environment Runner; 6.4.3 and 8.2.2 also cover the legacy SSR loader. Resource reads start at the watcher boundary without manual graph refresh. Concurrent soak latency is not comparative evidence. [Memory/shutdown values and limits](https://github.com/benpsnyder/analog/blob/6df41ba6421c8cbebd2d9de4c7f809b35ceb510a/packages/vite-plugin-angular/HMR_P95_SPRINT.md#correctness-and-bounded-soaks).

<a id="user-content-resource-invalidation-follow-up-pending-integration"></a>

## Integrated resource-invalidation correction

Qualified commit `efe3f93ff6c1e05d1873f23f582c27b51596b3af` was integrated as `31e7e7516`. Its tests and evidence are preserved. The original worktrees and history remain intact. This historical element ID remains stable for existing evidence links.

<a id="user-content-what-the-investigation-found-and-corrected"></a>

## What the investigation found and corrected

Exact-ID lookup missed query-qualified owners, mistook known unloaded owners for unknown ownership, and allowed new readers to reuse older pending transforms. The shared adapter now uses Vite’s file-to-module index, one visited set and file-invalidation timestamps while keeping dirtiness publication synchronous. Later style checks corrected shared external-Sass fallback freshness and metadata replay after Angular 19 reloads.

<a id="user-content-separate-qualification-for-the-local-follow-up"></a>

## Qualification of the integrated correction

Five regressions cover loaded/lazy owners, all-lazy owners, query-only owners, bare/query owners and a held real-Vite pending transform followed by a new read and cache recheck. They remain in the 983 passing package tests. [Regression source](https://github.com/benpsnyder/analog/blob/e66dfc92058e49c89efa722b88a9b0300a4a2707/packages/vite-plugin-angular/src/lib/compiler-environments.spec.ts), [original investigation and its separately attributed evidence](https://github.com/benpsnyder/analog/blob/e66dfc92058e49c89efa722b88a9b0300a4a2707/packages/vite-plugin-angular/HMR_DOWNSIDES.md).

<a id="user-content-ownership-comparison-without-manual-ssr-graph-refresh"></a>

## Ownership proof without manual SSR graph refresh

The final ngtsc/fast/API ownership workers pass 12 shared-resource edits and 48 fresh after-edit rendered SSR results, plus startup/lazy reads, while retaining unrelated-module identity. Current packed native source/resource races cover all three modes across Vite 6.0/6.4/8.2, including restarts and queued shutdown. [Ownership fixture](https://github.com/benpsnyder/analog/blob/e66dfc92058e49c89efa722b88a9b0300a4a2707/packages/vite-plugin-angular/scripts/compiler-ownership-qualification.mjs), [current raw archive](https://github.com/benpsnyder/analog/blob/6df41ba6421c8cbebd2d9de4c7f809b35ceb510a/packages/vite-plugin-angular/HMR_INTEGRATION.md#revisions-and-measurement-boundaries).

Older alpha/original-PR comparisons and nine earlier soaks remain historical evidence at their original revisions. They are not pooled with these results. [Historical HMR record](https://github.com/benpsnyder/analog/blob/0cf3f80025f2c7db8080700a2ac63d1874598de1/packages/vite-plugin-angular/EFFECT_REFACTOR.md#hmr-follow-up-behavior-and-tradeoffs).

<a id="user-content-remaining-downsides-and-next-bounded-experiments"></a>

## Performance disposition and remaining cautions

**The strict 5% acceptance gate remains unmet: 6/12 browser cells pass all four latency limits; first/warm build gates pass. The latency misses are detailed below. No overall speedup or completed performance-acceptance claim is made.**

The sprint accepted two bounded allocation reductions: byte-identical fast AST reuse and once-per-compilation API diagnostics. External-style caching was deferred after freshness review found an actual-unlink gap; it provides no evidence for ordinary API benchmark improvements. A separate warmup enabled/off diagnostic did not establish warming as the ngtsc tail's cause, so the ordering and 75 ms policy remain intact.

Previous ordinary-style auto-externalization experiments and failed performance gates remain in the [historical integration report](https://github.com/benpsnyder/analog/blob/6df41ba6421c8cbebd2d9de4c7f809b35ceb510a/packages/vite-plugin-angular/HMR_INTEGRATION.md#performance-results-and-acceptance). The new repaired-control cohort does not retroactively pass or pool those samples. No general cache, cross-generation emit cache, DOM snapshot/restore or duplicate renderer was introduced. Adoption remains a maintainer decision.

<a id="user-content-dependency-and-production-costs"></a>

## Dependency and production costs

Effect stays at `4.0.0-rc.112` as a direct Node compiler dependency, with Schema validation and typed failures. Historical Effect package-file accounting was **47,533,320 bytes**, compared with about 4.2 MB for the old es-toolkit package. Those figures are neither download size nor incremental pnpm-store allocation. Subpaths reduce loaded code without shrinking the installed package.

The new import/construction/build/CPU/heap values are recorded above. Older production regressions and first-SSR results remain in the [historical record](https://github.com/benpsnyder/analog/blob/0cf3f80025f2c7db8080700a2ac63d1874598de1/packages/vite-plugin-angular/EFFECT_REFACTOR.md#dependency-and-package-cost); they are not claims about this runtime. No equivalent optimized implementation without Effect was compared. [Pinned package exports](https://github.com/Effect-TS/effect/blob/effect%404.0.0-rc.112/packages/effect/package.json).

<a id="user-content-does-this-pr-introduce-a-breaking-change"></a>

## Does this PR introduce a breaking change?

- [ ] Yes
- [x] No public signature break

`angular(options): Plugin[]` remains. Owned-option Schema validation is stricter: malformed/unknown settings and visible stylesheet preprocessing failures require fixes in consumer configuration. Defaults and both escape hatches are documented. Metadata/reload fallback state limits and unsupported compiler/version combinations remain explicit. [Migration requirements](https://github.com/benpsnyder/analog/blob/6df41ba6421c8cbebd2d9de4c7f809b35ceb510a/apps/docs-analog/src/content/guides/migrating-v2-to-v3.md).

<a id="user-content-test-plan-and-current-ci"></a>

## Test plan and current CI

**2026-09-08 04:59 UTC snapshot at `6df41ba6421c8cbebd2d9de4c7f809b35ceb510a`:** **40 successful, 4 neutral and 0 failed checks; 0 pending.** [Windows packed-consumer job](https://github.com/analogjs/analog/actions/runs/34188232288/job/101940782893), [all checks](https://github.com/analogjs/analog/pull/2521/checks).

The preceding documentation-head run exposed the shared-style defect and Windows initial-render timeout described [in the follow-up](https://github.com/benpsnyder/analog/blob/6df41ba6421c8cbebd2d9de4c7f809b35ceb510a/packages/vite-plugin-angular/HMR_P95_SPRINT.md#ci-follow-up-and-unresolved-correctness). GitHub denied a failed-job rerun because the current account lacks repository admin rights. The runtime remains the measured `97366bd0` source; this snapshot does not erase the failed attempt.

983 package tests pass, with six existing skips; source/test typechecks, ESLint and build/artifact verification pass. All 13 packed Linux tuples, 15 additional style cases and 21 fallback/version/ownership checks pass. The expanded packed runner covers 19 style/encapsulation cases, six fast behavioral reloads, nine shared-Sass cases, native SSR races and restart/shutdown; Angular 19.0.1 covers both reload strategies. Nine new short soaks pass under five minutes per process.

[Current exact-artifact evidence and commands](https://github.com/benpsnyder/analog/blob/6df41ba6421c8cbebd2d9de4c7f809b35ceb510a/packages/vite-plugin-angular/HMR_P95_SPRINT.md#reproduction-and-evidence). Queued/skipped/neutral checks are not approval; the PR remains draft pending maintainer review.

<a id="user-content-reproduce-package-checks"></a>

## Reproduce package checks

Use Node 24.15.0 and pnpm 10.33.0:

```sh
pnpm install --frozen-lockfile
NX_DAEMON=false NX_NO_CLOUD=true pnpm nx run-many -p vite-plugin-angular -t test,typecheck,typecheck-tests,build --parallel=1
NX_DAEMON=false NX_NO_CLOUD=true pnpm nx run eslint:lint
node packages/vite-plugin-angular/scripts/compiler-vite-smoke.mjs --angular=22.0.0 --vite=8.2.2
```

<a id="user-content-reproduce-the-comparison"></a>

## Reproduce the comparison

Use Node 24.15.0 and pnpm 10.33.0. The [copyable replay instructions](https://github.com/benpsnyder/analog/blob/6df41ba6421c8cbebd2d9de4c7f809b35ceb510a/packages/vite-plugin-angular/HMR_P95_SPRINT.md#reproduction-and-evidence) use archived exact tarballs and locks, or rebuild from the recorded bases plus source patches. Run package/packed correctness first, then run comparative workers serially after owned tests/builds/profilers finish:

```sh
python3 "$QUAL_EVIDENCE/reproduce/fixed-cohort.py" --root "$QUAL_ROOT" --scripts "$QUAL_SCRIPTS" --output "$QUAL_ROOT/results" --node "$(command -v node)"
python3 "$QUAL_EVIDENCE/reproduce/summarize.py" "$QUAL_ROOT/results" > "$QUAL_ROOT/summary.json"
```

The driver runs 90 fresh build processes, 120 paired browser processes and 108 SSR-idle processes. Existing failures/incomplete logs are retained and untouched cells continue; never replace a failed observation with a retry. New suite invocations require `--manifest`; paired modes/phases use fresh output directories for their own protocol manifests.

<a id="user-content-reproduce-native-ssr-and-sustained-checks"></a>

## Reproduce native SSR and sustained checks

Outside the comparative timing window:

```sh
NODE_ENV=development node "$QUAL_SCRIPTS/compiler-qualification-suite.mjs" --root="$QUAL_ROOT" --manifest="$QUAL_EVIDENCE/revisions.json" --phase=soak --hmr --output="$QUAL_ROOT/short-soaks"
```

This admits nine all-mode correctness workers, each with a 240,000 ms update window and hard 300,000 ms total process timeout. The default `ngtsc` disposition filename labels the invocation, not its mode coverage. [Packed matrix, native style, ownership and source replay instructions](https://github.com/benpsnyder/analog/blob/6df41ba6421c8cbebd2d9de4c7f809b35ceb510a/packages/vite-plugin-angular/HMR_P95_SPRINT.md#reproduction-and-evidence). Historical 15-minute soaks remain attributed to their original cohorts.

<a id="user-content-evidence-archive"></a>

## Evidence archive

- [Current p95 sprint report](https://github.com/benpsnyder/analog/blob/6df41ba6421c8cbebd2d9de4c7f809b35ceb510a/packages/vite-plugin-angular/HMR_P95_SPRINT.md) and [machine-readable summary](https://github.com/benpsnyder/analog/blob/6df41ba6421c8cbebd2d9de4c7f809b35ceb510a/packages/vite-plugin-angular/hmr-p95-sprint-qualification.json).
- [New raw archive](https://github.com/benpsnyder/analog/blob/6df41ba6421c8cbebd2d9de4c7f809b35ceb510a/packages/vite-plugin-angular/evidence/hmr-p95-sprint/qualification-results.tar.gz): exact artifacts, source patches, manifests/locks, worker hashes, raw results, short soaks, control diagnostics and retained setup failures. Published hashes and normalization boundaries are in the report.
- [Synchronized PointsForBrandon.md](https://github.com/benpsnyder/analog/blob/6df41ba6421c8cbebd2d9de4c7f809b35ceb510a/PointsForBrandon.md).
- [Previous integration report](https://github.com/benpsnyder/analog/blob/6df41ba6421c8cbebd2d9de4c7f809b35ceb510a/packages/vite-plugin-angular/HMR_INTEGRATION.md) and its [unchanged archive](https://github.com/benpsnyder/analog/blob/6df41ba6421c8cbebd2d9de4c7f809b35ceb510a/packages/vite-plugin-angular/evidence/hmr-integration/qualification-results.tar.gz) retain earlier revisions, failures and long soaks. The [historical Effect/HMR record](https://github.com/benpsnyder/analog/blob/0cf3f80025f2c7db8080700a2ac63d1874598de1/packages/vite-plugin-angular/EFFECT_REFACTOR.md) remains separately attributed.

<a id="user-content-recommended-merge-strategy-for-maintainer"></a>

## Recommended merge strategy for maintainer

- [x] Squash merge
- [ ] Rebase merge
- [ ] Other

Forward commits preserve the review/evidence history. Squash remains the preferred maintainer integration strategy. The adoption decision and any remaining performance acceptance requirements are unresolved in the issue.
