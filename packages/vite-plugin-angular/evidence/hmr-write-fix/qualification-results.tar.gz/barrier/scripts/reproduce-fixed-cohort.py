"""Portable replay of the fixed write-barrier cohort; retain failures without replacement.

The recorded run used the separately archived orchestration scripts. This driver
accepts local paths, labels the sides explicitly, and can resume an interrupted
run without overwriting existing JSON observations. It runs serially.
"""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--scripts', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--node', default='node')
parser.add_argument('--phase', choices=['all', 'build', 'paired', 'idle'], default='all')
args = parser.parse_args()
root, scripts, output = args.root.resolve(), args.scripts.resolve(), args.output.resolve()
output.mkdir(parents=True, exist_ok=True)
node = shutil.which(args.node)
assert node and subprocess.check_output([node, '--version'], text=True).strip() == 'v24.15.0'
env = {**os.environ, 'NODE_ENV': 'development'}
env.pop('VITEST', None)
failures = []
for vite in [6, '6-latest', 7, 8]:
    for side in ['control', 'candidate']:
        shutil.copyfile(scripts / 'compiler-runtime-qualification.mjs', root / f'vite{vite}-{side}' / 'runtime.mjs')

def run(name, worker_args, cwd=scripts, extra=None):
    path = output / (name + '.json')
    if path.exists():
        data = json.loads(path.read_text())
        if data.get('passed') is False:
            failures.append(name)
        print(json.dumps({'name': name, 'retainedExisting': True}), flush=True)
        return
    if (output / (name + '.log')).exists():
        failures.append(name)
        print(json.dumps({'name': name, 'retainedIncompleteLog': True}), flush=True)
        return
    started = time.time()
    with (output / (name + '.log')).open('w') as log:
        proc = subprocess.run([node, *worker_args], cwd=cwd, env={**env, **(extra or {})}, stdout=log, stderr=subprocess.STDOUT)
    print(json.dumps({'name': name, 'exitCode': proc.returncode, 'seconds': time.time() - started}), flush=True)
    if proc.returncode:
        failures.append(name)
        if not name.startswith('paired-'):
            raise SystemExit(proc.returncode)

if args.phase in ['all', 'build']:
    for mode in ['ngtsc', 'fast', 'api']:
        run('build-' + mode, [str(scripts / 'compiler-benchmark.mjs'), f'--baseline={root / "vite8-control"}', f'--candidate={root / "vite8-candidate"}', f'--output={output / f"build-{mode}.json"}', '--samples=15'], extra={'ANALOG_PERF_FAST': '1' if mode == 'fast' else '0', 'ANALOG_PERF_API': '1' if mode == 'api' else '0'})
if args.phase in ['all', 'paired']:
    for mode in ['ngtsc', 'fast', 'api']:
        for vite in [6, '6-latest', 7, 8]:
            for sample in range(5):
                for side in (['candidate', 'control'] if sample % 2 else ['control', 'candidate']):
                    name = f'paired-vite{vite}-{side}-{mode}-{sample}'
                    run(name, ['--expose-gc', 'runtime.mjs', f'--mode={mode}', f'--label={side}', '--edits=25', '--event-latency', f'--output={output / (name + ".json")}', *(['--expect-style-state'] if side == 'candidate' else [])], cwd=root / f'vite{vite}-{side}')
if args.phase in ['all', 'idle']:
    for mode in ['ngtsc', 'fast', 'api']:
        for idle in [0, 250, 1000]:
            for order in ['browser', 'server']:
                for sample in range(3):
                    for warmup in (['default', 'off'] if sample % 2 else ['off', 'default']):
                        name = f'idle-{mode}-{idle}-{order}-{warmup}-{sample}'
                        run(name, ['--expose-gc', 'runtime.mjs', f'--mode={mode}', '--components=100', '--edits=5', f'--ssr-idle-ms={idle}', f'--warmup={warmup}', f'--output={output / (name + ".json")}', *(['--ssr-first'] if order == 'server' else [])], cwd=root / 'vite8-candidate')
(output / 'complete.json').write_text(json.dumps({'completed': True, 'phase': args.phase, 'failures': failures}) + '\n')
if failures:
    print('Retained failed workers: ' + ', '.join(failures))
    raise SystemExit(1)
